<?php

class seller extends user
{


    function addProduct($id, $product)
    {
    }

    function updateProduct($id, $prodct)
    {
    }
    function deleteProduct($id)
    {
    }
}
