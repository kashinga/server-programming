# Fonts

## Logo Fonts

### Audiowide

## Text fonts

### Roboto, -apple-system, "Segoe UI", "Helvetica Neue", Arial, sans-serif;

## ICONS -box icons

-Jumia - star
-Jumia Food logo - meteor
-Jumia Pay - shield-quarter
-Jumia force- star

## responsive images

<picture>
<source
              media="(max-width: 768px)"
              srcset="./assets/top_banner_sm.gif"
            />
<source
              media="(min-width: 769px)"
              srcset="./assets/top_banner.gif"
            />
<img src="./assets/top_banner.gif" alt="Image" />
</picture>
